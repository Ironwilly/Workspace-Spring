package com.salesianostriana.dam.primerproyectodatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ec04IntroSpringDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
